<!-- Main content --> 
<section class="content">

  <!-- Default box -->
  <div class="box"> 
    <div class="box-header with-border">

      <div class="box-tools pull-right">
        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
          <i class="fa fa-minus"></i></button>
        <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
          <i class="fa fa-times"></i></button>
      </div>
    </div>
    <div class="box-body">
      
      <div class="bg-alice">
        <span><u>File yang di download akan berformat .zip, extract untuk mengambil file .sql di dalamnya</u></span>
        <br/> 
        <span><u>Klik download database</u></span> 
        <br/><br/>
        <a href="<?= base_url('pengaturan/backup_download') ?>"><button class="btn btn-primary">Download <i class="fa fa-download"></i></button></a>
      </div>

    </div>
  </div>
  <!-- /.box -->