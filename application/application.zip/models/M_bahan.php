<?php

class M_bahan extends CI_Model { 

	//nama tabel
	var $table = 't_bahan'; 

	//kolom yang di tampilkan
	var $column_order = array(null, 'bahan_nama','bahan_kategori'); 

	//kolom yang di tampilkan setelah seacrh
	var $column_search = array('bahan_nama','bahan_kategori','gudang_nama'); 

	//urutan 
	var $order = array('bahan_id' => 'asc'); 

	public function __construct()
	{ 
		parent::__construct();
		$this->load->database();
	}

	private function _get_datatables_query()
	{
		
		$this->db->from($this->table);

		$i = 0;
	
		foreach ($this->column_search as $item) // loop column 
		{
			if($_GET['search']['value']) // if datatable send POST for search
			{
				
				if($i===0) // first loop
				{
					$this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
					$this->db->like($item, $_GET['search']['value']);
				}
				else
				{
					$this->db->or_like($item, $_GET['search']['value']);
				}

				if(count($this->column_search) - 1 == $i) //last loop
					$this->db->group_end(); //close bracket
			}
			$i++;
		}
		
		if(isset($_GET['order'])) // here order processing
		{
			$this->db->order_by($this->column_order[$_GET['order']['0']['column']], $_GET['order']['0']['dir']);
		} 
		else if(isset($this->order))
		{
			$order = $this->order;
			$this->db->order_by(key($order), $order[key($order)]);
		}
	}

	function get_datatables($where)
	{
		$this->db->select('*');
		$this->db->select('IFNULL(SUM(bahan_gudang_berat), 0) AS berat');
		$this->db->select('IFNULL(SUM(bahan_gudang_panjang), 0) AS panjang');
		$this->db->select('IFNULL(SUM(bahan_gudang_hpp), 0) AS hpp');
		$this->_get_datatables_query();
		if($_GET['length'] != -1)
		$this->db->where($where);
		$this->db->join('t_bahan_gudang', 't_bahan_gudang.bahan_gudang_bahan = t_bahan.bahan_id', 'left');
		$this->db->join('t_gudang', 't_gudang.gudang_id = t_bahan_gudang.bahan_gudang_gudang', 'left');
		$this->db->join('t_satuan', 't_satuan.satuan_id = t_bahan.bahan_satuan', 'left');
		$this->db->limit($_GET['length'], $_GET['start']);
		$this->db->group_by('bahan_id');
		$this->db->group_by('bahan_gudang_gudang'); 
		$query = $this->db->get();
		return $query->result();
	}

	function count_filtered($where)
	{
		$this->_get_datatables_query();
		$this->db->join('t_bahan_gudang', 't_bahan_gudang.bahan_gudang_bahan = t_bahan.bahan_id', 'left');
		$this->db->join('t_gudang', 't_gudang.gudang_id = t_bahan_gudang.bahan_gudang_gudang', 'left');
		$this->db->join('t_satuan', 't_satuan.satuan_id = t_bahan.bahan_satuan', 'left');
		$this->db->where($where);
		$query = $this->db->get();
		return $query->num_rows();
	}

	public function count_all($where)
	{
		$this->db->from($this->table);
		$this->db->join('t_bahan_gudang', 't_bahan_gudang.bahan_gudang_bahan = t_bahan.bahan_id', 'left');
		$this->db->join('t_gudang', 't_gudang.gudang_id = t_bahan_gudang.bahan_gudang_gudang', 'left');
		$this->db->join('t_satuan', 't_satuan.satuan_id = t_bahan.bahan_satuan', 'left');
		$this->db->where($where);
		return $this->db->count_all_results();
	}

	// 
	function get_data_hpp($id_bahan)
	{
		$sql = "
			SELECT 
				b.pembelian_barang_barang AS bahan, 
				b.pembelian_barang_nomor AS nomor,
			    b.pembelian_barang_berat AS berat, 
			    b.pembelian_barang_panjang AS panjang, 
			    b.pembelian_barang_total AS total,
			    b.pembelian_barang_ekspedisi AS ekspedisi,
			    a.pembelian_gudang AS gudang,
			    c.bahan_nama,
			    b.pembelian_barang_harga AS harga
			FROM t_pembelian AS a 
			JOIN t_pembelian_barang AS b ON a.pembelian_nomor = b.pembelian_barang_nomor 
			JOIN t_bahan AS c ON b.pembelian_barang_barang = c.bahan_id
			WHERE a.pembelian_hapus = 0 AND b.pembelian_barang_barang = '{$id_bahan}'
		";
		return $this->db->query($sql)->result();		
	}
}
